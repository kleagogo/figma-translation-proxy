# 🚀 Figma Translation Proxy - Vercel Deployment

This is a Vercel-hosted proxy service that enables your Figma plugin to translate text using the Langdock API.

## 📋 **Setup Instructions**

### 1. **Deploy to Vercel**

```bash
# Clone/copy this folder to your personal Vercel project
cd vercel-proxy
npm install
vercel --prod
```

### 2. **Set Environment Variable**

In your **Vercel Dashboard**:
1. Go to your project settings
2. Navigate to "Environment Variables"
3. Add a new variable:
   - **Name:** `LANGDOCK_API_KEY`
   - **Value:** `sk-ov6LO2pO5pxcztJfmMrJ6_KCd8BdoWRdpwYN4DPQ35GsQhzgaIQL_zbWC5IgYj3SZRxWUk78iiJgVxvXK9oxXQ`
   - **Environment:** Production, Preview, Development

### 3. **Get Your Proxy URL**

After deployment, Vercel will give you a URL like:
```
https://your-project-name.vercel.app
```

Your translation endpoint will be:
```
https://your-project-name.vercel.app/api/translate
```

## 🔧 **Local Development**

```bash
# Install dependencies
npm install

# Create local environment file
echo "LANGDOCK_API_KEY=sk-ov6LO2pO5pxcztJfmMrJ6_KCd8BdoWRdpwYN4DPQ35GsQhzgaIQL_zbWC5IgYj3SZRxWUk78iiJgVxvXK9oxXQ" > .env.local

# Start development server
npm run dev
```

## 📡 **API Usage**

### **Endpoint:** `POST /api/translate`

**Request:**
```json
{
  "text": "Hello world",
  "targetLanguage": "German"
}
```

**Response:**
```json
{
  "success": true,
  "originalText": "Hello world",
  "translatedText": "Hallo Welt",
  "targetLanguage": "German"
}
```

## 🔒 **Security Features**

- ✅ CORS enabled for Figma plugin access
- ✅ API key stored securely in Vercel environment
- ✅ Error handling and validation
- ✅ Rate limiting through Vercel's built-in limits

## 🎯 **Next Steps**

1. **Deploy this proxy** to your personal Vercel account
2. **Update your Figma plugin** to use your proxy URL
3. **Test the integration** in Figma

Your Figma plugin will now work by calling your Vercel proxy instead of directly calling Langdock! 🎉 