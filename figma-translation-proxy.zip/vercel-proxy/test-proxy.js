// Simple test script to verify the proxy API
// Run this after deploying to Vercel: node test-proxy.js

const PROXY_URL = 'https://YOUR-VERCEL-URL.vercel.app/api/translate';

async function testProxy() {
  console.log('🧪 Testing Figma Translation Proxy...');
  console.log('📡 URL:', PROXY_URL);
  
  const testData = {
    text: "Hello world",
    targetLanguage: "German"
  };
  
  try {
    console.log('📤 Sending:', JSON.stringify(testData, null, 2));
    
    const response = await fetch(PROXY_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(testData)
    });
    
    console.log('📊 Status:', response.status);
    
    const result = await response.json();
    console.log('📥 Response:', JSON.stringify(result, null, 2));
    
    if (result.success && result.translatedText) {
      console.log('✅ SUCCESS! Translation proxy is working correctly.');
      console.log(`🎯 "${testData.text}" → "${result.translatedText}"`);
    } else {
      console.log('❌ FAILED! Check your environment variables.');
    }
    
  } catch (error) {
    console.log('❌ ERROR:', error.message);
    console.log('💡 Make sure to update PROXY_URL with your actual Vercel URL');
  }
}

// Uncomment the line below and update PROXY_URL to test
// testProxy(); 