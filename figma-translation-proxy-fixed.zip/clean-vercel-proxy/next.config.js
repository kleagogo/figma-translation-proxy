/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Enable API routes
  pageExtensions: ['ts', 'tsx', 'js', 'jsx'],
  // Optimize for Vercel deployment
  experimental: {
    // Enable server components
  }
}

module.exports = nextConfig 